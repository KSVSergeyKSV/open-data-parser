// Global state
let appState = {
    currentStep: 1,
    dataFile: null,
    registryData: null,
    orderData: null,
    templateData: null,
    docxTemplate: null,
    rawData: [],
    headers: [],
    structure: [],
    passport: {},
    convertedData: null,
    selectedDataset: null,
    datasetFilter: {
        search: '',
        owner: '',
        status: ''
    },
    currentPage: 1,
    itemsPerPage: 10
};

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    setupEventListeners();
    setDefaultDate();
    loadDocxTemplate();
});

async function loadDocxTemplate() {
    try {
        const response = await fetch('templates/passport-template.docx');
        if (!response.ok) throw new Error('Template not found');
        const arrayBuffer = await response.arrayBuffer();
        appState.docxTemplate = arrayBuffer;
        console.log('DOCX template loaded successfully');
    } catch (err) {
        console.warn('Could not load DOCX template, will use fallback generation:', err);
        appState.docxTemplate = null;
    }
}

function setupEventListeners() {
    // File inputs
    document.getElementById('registryFile').addEventListener('change', handleRegistryFile);
    document.getElementById('orderFile').addEventListener('change', handleOrderFile);
    document.getElementById('templateFile').addEventListener('change', handleTemplateFile);
    document.getElementById('dataFile').addEventListener('change', handleDataFile);
    
    // Dataset selection filters
    document.getElementById('datasetSearch').addEventListener('input', (e) => {
        appState.datasetFilter.search = e.target.value.toLowerCase();
        appState.currentPage = 1;
        renderDatasetTable();
    });
    document.getElementById('filterOwner').addEventListener('change', (e) => {
        appState.datasetFilter.owner = e.target.value;
        appState.currentPage = 1;
        renderDatasetTable();
    });
    document.getElementById('filterStatus').addEventListener('change', (e) => {
        appState.datasetFilter.status = e.target.value;
        appState.currentPage = 1;
        renderDatasetTable();
    });
    
    // Pagination
    document.getElementById('prevPage').addEventListener('click', () => {
        if (appState.currentPage > 1) {
            appState.currentPage--;
            renderDatasetTable();
        }
    });
    document.getElementById('nextPage').addEventListener('click', () => {
        const filteredData = getFilteredDatasets();
        const totalPages = Math.ceil(filteredData.length / appState.itemsPerPage);
        if (appState.currentPage < totalPages) {
            appState.currentPage++;
            renderDatasetTable();
        }
    });
    
    // Navigation buttons
    document.getElementById('btnStep1').addEventListener('click', () => goToStep(2));
    document.getElementById('btnBack2').addEventListener('click', () => goToStep(1));
    document.getElementById('btnStep2').addEventListener('click', () => goToStep(3));
    document.getElementById('btnBack3').addEventListener('click', () => goToStep(2));
    document.getElementById('btnStep3').addEventListener('click', () => goToStep(4));
    document.getElementById('btnBack4').addEventListener('click', () => goToStep(3));
    document.getElementById('btnConvert').addEventListener('click', convertAndValidate);
    document.getElementById('btnStep4').addEventListener('click', () => goToStep(5));
    document.getElementById('btnBack5').addEventListener('click', () => goToStep(4));
    document.getElementById('btnDownload').addEventListener('click', downloadArchive);
}

function setDefaultDate() {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('publishDate').value = today;
}

// File handlers
function handleRegistryFile(e) {
    const file = e.target.files[0];
    if (!file) return;
    
    readExcelFile(file).then(data => {
        appState.registryData = data;
        populateOwnerFilter(data);
        showDatasetSelectionPanel();
        checkStep1Complete();
    }).catch(err => {
        console.error('Error reading registry:', err);
        alert('Ошибка чтения файла реестра');
    });
}

function showDatasetSelectionPanel() {
    document.getElementById('datasetSelectionPanel').style.display = 'block';
    renderDatasetTable();
}

function populateOwnerFilter(data) {
    const select = document.getElementById('filterOwner');
    const owners = new Set();
    
    // Try to find owner column
    const possibleOwnerCols = ['owner', 'Owner', 'владелец', 'Владелец', 'ведомство', 'Ведомство'];
    let ownerCol = possibleOwnerCols.find(col => 
        data.length > 0 && Object.keys(data[0]).includes(col)
    );
    
    if (!ownerCol && data.length > 0) {
        ownerCol = Object.keys(data[0]).find(key => 
            key.toLowerCase().includes('owner') || key.toLowerCase().includes('владелец')
        ) || Object.keys(data[0])[1];
    }
    
    data.forEach(row => {
        if (ownerCol && row[ownerCol]) {
            owners.add(row[ownerCol]);
        }
    });
    
    select.innerHTML = '<option value="">Все владельцы</option>';
    owners.forEach(owner => {
        const option = document.createElement('option');
        option.value = owner;
        option.textContent = owner;
        select.appendChild(option);
    });
}

function getFilteredDatasets() {
    if (!appState.registryData) return [];
    
    return appState.registryData.filter(row => {
        // Get column names dynamically
        const keys = Object.keys(row);
        
        // Find name column
        const nameCol = keys.find(k => 
            k.toLowerCase().includes('name') || k.toLowerCase().includes('наименование')
        ) || keys[0];
        
        // Find owner column
        const ownerCol = keys.find(k => 
            k.toLowerCase().includes('owner') || k.toLowerCase().includes('владелец') || k.toLowerCase().includes('ведомство')
        ) || keys[1];
        
        // Find status column
        const statusCol = keys.find(k => 
            k.toLowerCase().includes('status') || k.toLowerCase().includes('статус')
        ) || keys[4];
        
        // Apply filters
        const nameValue = String(row[nameCol] || '').toLowerCase();
        const ownerValue = row[ownerCol] || '';
        const statusValue = row[statusCol] || '';
        
        const matchesSearch = !appState.datasetFilter.search || 
            nameValue.includes(appState.datasetFilter.search);
        const matchesOwner = !appState.datasetFilter.owner || 
            ownerValue === appState.datasetFilter.owner;
        const matchesStatus = !appState.datasetFilter.status || 
            statusValue === appState.datasetFilter.status;
        
        return matchesSearch && matchesOwner && matchesStatus;
    });
}

function renderDatasetTable() {
    const filteredData = getFilteredDatasets();
    const tbody = document.getElementById('datasetTableBody');
    const pagination = document.getElementById('pagination');
    
    if (filteredData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;">Наборы ОД не найдены</td></tr>';
        pagination.style.display = 'none';
        return;
    }
    
    // Pagination
    const totalPages = Math.ceil(filteredData.length / appState.itemsPerPage);
    const startIndex = (appState.currentPage - 1) * appState.itemsPerPage;
    const endIndex = startIndex + appState.itemsPerPage;
    const pageData = filteredData.slice(startIndex, endIndex);
    
    // Get column names from first row
    const keys = Object.keys(pageData[0] || {});
    const nameCol = keys.find(k => k.toLowerCase().includes('name') || k.toLowerCase().includes('наименование')) || keys[0];
    const idCol = keys.find(k => k.toLowerCase() === 'id' || k.toLowerCase().includes('идентификатор')) || keys[0];
    const ownerCol = keys.find(k => k.toLowerCase().includes('owner') || k.toLowerCase().includes('владелец') || k.toLowerCase().includes('ведомство')) || keys[1];
    const responsibleCol = keys.find(k => k.toLowerCase().includes('ответственный') || k.toLowerCase().includes('фио')) || keys[2];
    const statusCol = keys.find(k => k.toLowerCase().includes('status') || k.toLowerCase().includes('статус')) || keys[4];
    const descCol = keys.find(k => k.toLowerCase().includes('описание') || k.toLowerCase().includes('description')) || keys[5];
    
    let html = '';
    pageData.forEach((row, index) => {
        const globalIndex = startIndex + index;
        const isSelected = appState.selectedDataset && 
            appState.selectedDataset.rowIndex === globalIndex;
        
        html += `<tr class="${isSelected ? 'selected' : ''}" data-index="${globalIndex}">`;
        html += `<td>${escapeHtml(row[idCol] || '')}</td>`;
        html += `<td>${escapeHtml(row[nameCol] || '')}</td>`;
        html += `<td>${escapeHtml(row[ownerCol] || '')}</td>`;
        html += `<td>${escapeHtml(row[responsibleCol] || '')}</td>`;
        html += `<td>${escapeHtml(row[statusCol] || '')}</td>`;
        html += `<td>${escapeHtml(row[descCol] || '')}</td>`;
        html += '</tr>';
    });
    
    tbody.innerHTML = html;
    
    // Add click handlers
    tbody.querySelectorAll('tr').forEach(tr => {
        tr.addEventListener('click', () => selectDataset(parseInt(tr.dataset.index)));
    });
    
    // Update pagination
    if (totalPages > 1) {
        pagination.style.display = 'flex';
        document.getElementById('pageInfo').textContent = `Страница ${appState.currentPage} из ${totalPages}`;
        document.getElementById('prevPage').disabled = appState.currentPage === 1;
        document.getElementById('nextPage').disabled = appState.currentPage === totalPages;
    } else {
        pagination.style.display = 'none';
    }
}

function selectDataset(rowIndex) {
    const filteredData = getFilteredDatasets();
    const selectedRow = filteredData[rowIndex];
    
    if (!selectedRow) return;
    
    // Get column names
    const keys = Object.keys(selectedRow);
    const idCol = keys.find(k => k.toLowerCase() === 'id' || k.toLowerCase().includes('идентификатор')) || keys[0];
    const nameCol = keys.find(k => k.toLowerCase().includes('name') || k.toLowerCase().includes('наименование')) || keys[0];
    const ownerCol = keys.find(k => k.toLowerCase().includes('owner') || k.toLowerCase().includes('владелец') || k.toLowerCase().includes('ведомство')) || keys[1];
    const responsibleCol = keys.find(k => k.toLowerCase().includes('ответственный') || k.toLowerCase().includes('фио')) || keys[2];
    const statusCol = keys.find(k => k.toLowerCase().includes('status') || k.toLowerCase().includes('статус')) || keys[4];
    const descCol = keys.find(k => k.toLowerCase().includes('описание') || k.toLowerCase().includes('description')) || keys[5];
    
    appState.selectedDataset = {
        rowIndex: rowIndex,
        data: selectedRow,
        id: selectedRow[idCol],
        name: selectedRow[nameCol],
        owner: selectedRow[ownerCol],
        responsible: selectedRow[responsibleCol],
        status: selectedRow[statusCol],
        description: selectedRow[descCol]
    };
    
    // Update UI
    renderDatasetTable();
    showSelectedDatasetInfo();
    prefillPassportFromDataset();
    checkStep1Complete();
    
    // Log selection for audit
    console.log(`[${new Date().toISOString()}] Dataset selected: ID=${appState.selectedDataset.id}, Name=${appState.selectedDataset.name}`);
}

function showSelectedDatasetInfo() {
    const infoPanel = document.getElementById('selectedDatasetInfo');
    const dataset = appState.selectedDataset;
    
    if (!dataset) {
        infoPanel.style.display = 'none';
        return;
    }
    
    document.getElementById('infoId').textContent = dataset.id || '-';
    document.getElementById('infoName').textContent = dataset.name || '-';
    document.getElementById('infoOwner').textContent = dataset.owner || '-';
    document.getElementById('infoResponsible').textContent = dataset.responsible || '-';
    document.getElementById('infoStatus').textContent = dataset.status || '-';
    document.getElementById('infoDescription').textContent = dataset.description || '-';
    
    infoPanel.style.display = 'block';
}

function prefillPassportFromDataset() {
    if (!appState.selectedDataset) return;
    
    const dataset = appState.selectedDataset;
    
    if (dataset.name) {
        document.getElementById('datasetName').value = dataset.name;
    }
    if (dataset.owner) {
        document.getElementById('owner').value = dataset.owner;
    }
    if (dataset.responsible) {
        document.getElementById('responsible').value = dataset.responsible;
    }
    if (dataset.description) {
        document.getElementById('description').value = dataset.description;
    }
}

function handleOrderFile(e) {
    const file = e.target.files[0];
    if (!file) return;
    
    readExcelFile(file).then(data => {
        appState.orderData = data;
        // Try to pre-fill passport from order data
        prefillPassportFromOrder(data);
        checkStep1Complete();
    }).catch(err => {
        console.error('Error reading order:', err);
    });
}

function handleTemplateFile(e) {
    const file = e.target.files[0];
    if (!file) return;
    
    readExcelFile(file).then(data => {
        appState.templateData = data;
        checkStep1Complete();
    }).catch(err => {
        console.error('Error reading template:', err);
    });
}

function handleDataFile(e) {
    const file = e.target.files[0];
    if (!file) return;
    
    appState.dataFile = file;
    
    readExcelFile(file).then(data => {
        if (data.length === 0) {
            alert('Файл пуст или не содержит данных');
            return;
        }
        
        appState.rawData = data;
        appState.headers = Object.keys(data[0]);
        
        displayDataTable(data);
        generateStructure();
        checkStep1Complete();
    }).catch(err => {
        console.error('Error reading data file:', err);
        alert('Ошибка чтения файла данных');
    });
}

function readExcelFile(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        
        reader.onload = (e) => {
            try {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                
                // Read first sheet
                const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
                const jsonData = XLSX.utils.sheet_to_json(firstSheet);
                
                resolve(jsonData);
            } catch (err) {
                reject(err);
            }
        };
        
        reader.onerror = reject;
        reader.readAsArrayBuffer(file);
    });
}


function prefillPassportFromOrder(data) {
    if (!data || data.length === 0) return;
    
    const row = data[0];
    
    // Try to find common fields
    const fieldMappings = {
        'owner': ['owner', 'Owner', 'владелец', 'Владелец', 'ведомство', 'Ведомство'],
        'responsible': ['responsible', 'Responsible', 'ответственный', 'Ответственный', 'ФИО', 'фио'],
        'description': ['description', 'Description', 'описание', 'Описание']
    };
    
    for (const [field, possibleKeys] of Object.entries(fieldMappings)) {
        const foundKey = possibleKeys.find(key => 
            Object.keys(row).includes(key)
        );
        
        if (foundKey && row[foundKey]) {
            const inputId = field === 'owner' ? 'owner' : field === 'responsible' ? 'responsible' : 'description';
            const input = document.getElementById(inputId);
            if (input) {
                input.value = row[foundKey];
            }
        }
    }
}

function displayDataTable(data) {
    const container = document.getElementById('dataTableContainer');
    const table = document.getElementById('dataTable');
    
    if (data.length === 0) {
        container.style.display = 'none';
        return;
    }
    
    const headers = Object.keys(data[0]);
    
    let html = '<thead><tr>';
    headers.forEach(header => {
        html += `<th>${escapeHtml(header)}</th>`;
    });
    html += '</tr></thead><tbody>';
    
    // Show first 10 rows
    data.slice(0, 10).forEach(row => {
        html += '<tr>';
        headers.forEach(header => {
            html += `<td>${escapeHtml(row[header] || '')}</td>`;
        });
        html += '</tr>';
    });
    
    html += '</tbody>';
    table.innerHTML = html;
    container.style.display = 'block';
    
    if (data.length > 10) {
        const info = document.createElement('p');
        info.textContent = `Показано 10 из ${data.length} строк`;
        info.style.color = '#666';
        info.style.marginTop = '10px';
        container.appendChild(info);
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function generateStructure() {
    if (appState.rawData.length === 0) return;
    
    const sampleRow = appState.rawData[0];
    const headers = Object.keys(sampleRow);
    
    appState.structure = headers.map(header => {
        const sampleValue = sampleRow[header];
        const dataType = detectDataType(sampleValue);
        const description = generateFieldDescription(header);
        
        return {
            fieldname: header,
            description: description,
            format: dataType
        };
    });
    
    displayStructure();
}

function detectDataType(value) {
    if (value === null || value === undefined || value === '') {
        return 'string';
    }
    
    if (typeof value === 'number') {
        return 'number';
    }
    
    if (typeof value === 'boolean') {
        return 'boolean';
    }
    
    // Check for date patterns
    const datePatterns = [
        /^\d{4}-\d{2}-\d{2}$/,
        /^\d{2}\.\d{2}\.\d{4}$/,
        /^\d{2}\/\d{2}\/\d{4}$/
    ];
    
    if (typeof value === 'string') {
        if (datePatterns.some(pattern => pattern.test(value))) {
            return 'date';
        }
        
        // Check if it's a number stored as string
        if (!isNaN(parseFloat(value)) && isFinite(value)) {
            return 'number';
        }
    }
    
    return 'string';
}

function generateFieldDescription(fieldName) {
    // Simple Russian description generator
    const descriptions = {
        'id': 'Идентификатор записи',
        'name': 'Наименование',
        'Name': 'Наименование',
        'date': 'Дата',
        'Date': 'Дата',
        'value': 'Значение',
        'Value': 'Значение',
        'type': 'Тип',
        'Type': 'Тип',
        'status': 'Статус',
        'Status': 'Статус',
        'code': 'Код',
        'Code': 'Код',
        'description': 'Описание',
        'Description': 'Описание'
    };
    
    return descriptions[fieldName] || `Поле "${fieldName}"`;
}

function displayStructure() {
    const table = document.getElementById('structureTable');
    
    let html = '<thead><tr><th>Поле</th><th>Описание</th><th>Формат</th></tr></thead><tbody>';
    
    appState.structure.forEach(struct => {
        html += `<tr>
            <td>${escapeHtml(struct.fieldname)}</td>
            <td>${escapeHtml(struct.description)}</td>
            <td>${struct.format}</td>
        </tr>`;
    });
    
    html += '</tbody>';
    table.innerHTML = html;
}

function checkStep1Complete() {
    const btn = document.getElementById('btnStep1');
    const errorDiv = document.getElementById('step1Error');
    
    const hasData = appState.rawData.length > 0;
    const hasSelectedDataset = appState.selectedDataset !== null;
    
    if (!hasSelectedDataset && appState.registryData) {
        errorDiv.textContent = '⚠️ Пожалуйста, выберите набор ОД из реестра перед продолжением.';
        errorDiv.style.display = 'block';
        btn.disabled = true;
        return;
    }
    
    errorDiv.style.display = 'none';
    btn.disabled = !hasData;
}

// Navigation
function goToStep(step) {
    // Hide all steps
    document.querySelectorAll('.step-content').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.step').forEach(el => el.classList.remove('active'));
    
    // Show target step
    document.getElementById(`step${step}`).classList.add('active');
    document.querySelector(`.step[data-step="${step}"]`).classList.add('active');
    
    // Mark completed steps
    for (let i = 1; i < step; i++) {
        document.querySelector(`.step[data-step="${i}"]`).classList.add('completed');
    }
    
    appState.currentStep = step;
    
    // Pre-fill passport if moving to step 3
    if (step === 3) {
        prefillPassport();
    }
}

function prefillPassport() {
    // Prefill from selected dataset in registry (already done in prefillPassportFromDataset)
    // This function is kept for backward compatibility
    
    // Auto-generate description if empty
    const nameInput = document.getElementById('datasetName');
    const descInput = document.getElementById('description');
    
    if (!descInput.value && nameInput.value) {
        descInput.value = `Набор данных "${nameInput.value}", предоставленный для публикации на портале открытых данных.`;
    }
}

// Step 4: Conversion and Validation
function convertAndValidate() {
    const statusDiv = document.getElementById('conversionStatus');
    const validationDiv = document.getElementById('validationResult');
    
    statusDiv.innerHTML = '<p>Конвертация данных...</p>';
    validationDiv.style.display = 'none';
    
    try {
        // Convert to CSV
        const csv = convertToCSV(appState.rawData);
        appState.convertedData = csv;
        
        // Validate against template if available
        let isValid = true;
        let validationMessage = 'Конвертация успешно выполнена!';
        
        if (appState.templateData && appState.templateData.length > 0) {
            const validationResult = validateAgainstTemplate(csv, appState.templateData);
            isValid = validationResult.valid;
            validationMessage = validationResult.message;
        } else {
            validationMessage = 'Конвертация успешно выполнена! Эталонный файл структуры не загружен, проверка не выполнена.';
        }
        
        statusDiv.innerHTML = '<p>Данные сконвертированы в формат CSV.</p>';
        
        validationDiv.className = isValid ? 'success' : 'error';
        validationDiv.innerHTML = `<p>${escapeHtml(validationMessage)}</p>`;
        validationDiv.style.display = 'block';
        
        if (isValid) {
            document.getElementById('btnStep4').style.display = 'inline-block';
        }
        
    } catch (err) {
        console.error('Conversion error:', err);
        statusDiv.innerHTML = '<p>Ошибка конвертации: ' + escapeHtml(err.message) + '</p>';
        validationDiv.className = 'error';
        validationDiv.innerHTML = '<p>Произошла ошибка при конвертации данных</p>';
        validationDiv.style.display = 'block';
    }
}

function convertToCSV(data) {
    if (!data || data.length === 0) return '';
    
    const headers = Object.keys(data[0]);
    const rows = data.map(row => 
        headers.map(header => {
            const value = row[header];
            if (value === null || value === undefined) return '';
            const str = String(value);
            // Escape quotes and wrap in quotes if contains comma or quote
            if (str.includes(',') || str.includes('"') || str.includes('\n')) {
                return '"' + str.replace(/"/g, '""') + '"';
            }
            return str;
        }).join(',')
    );
    
    return [headers.join(','), ...rows].join('\n');
}

function validateAgainstTemplate(csvData, templateData) {
    // Simple validation - check if headers match
    const csvLines = csvData.split('\n');
    if (csvLines.length === 0) {
        return { valid: false, message: 'CSV файл пуст' };
    }
    
    const csvHeaders = csvLines[0].split(',').map(h => h.trim());
    
    if (templateData.length > 0) {
        const templateHeaders = Object.keys(templateData[0]);
        
        // Check if all template headers are present in CSV
        const missingHeaders = templateHeaders.filter(h => !csvHeaders.includes(h));
        
        if (missingHeaders.length > 0) {
            return {
                valid: false,
                message: `Отсутствуют поля: ${missingHeaders.join(', ')}`
            };
        }
    }
    
    return { valid: true, message: 'Все проверки пройдены успешно!' };
}

// Step 5: Generate and Download Archive
function downloadArchive() {
    try {
        const zip = new JSZip();
        
        // Generate all files
        const dataCsv = appState.convertedData || convertToCSV(appState.rawData);
        const structureJson = JSON.stringify(appState.structure, null, 2);
        const metaJson = generateMetaJson();
        
        // Add files to zip
        zip.file('data.csv', dataCsv);
        zip.file('structure.json', structureJson);
        zip.file('meta.json', metaJson);
        
        // Generate DOCX
        const metaDocxBlob = generateMetaDocx();
        zip.file('meta.docx', metaDocxBlob);
        
        // Generate and save zip
        zip.generateAsync({ type: 'blob' }).then(content => {
            saveAs(content, 'open_data_package.zip');
        });
        
    } catch (err) {
        console.error('Download error:', err);
        alert('Ошибка создания архива: ' + err.message);
    }
}

function generateMetaJson() {
    const passport = collectPassportData();
    
    const meta = {
        title: passport.datasetName || 'Набор данных',
        owner: passport.owner || 'Не указан',
        responsiblePerson: passport.responsible || 'Не указан',
        publishDate: passport.publishDate || new Date().toISOString().split('T')[0],
        description: passport.description || '',
        keywords: passport.keywords ? passport.keywords.split(',').map(k => k.trim()) : [],
        structure: appState.structure.map(s => ({
            fieldname: s.fieldname,
            description: s.description,
            format: s.format
        })),
        recordCount: appState.rawData.length,
        generatedAt: new Date().toISOString()
    };
    
    return JSON.stringify(meta, null, 2);
}

function collectPassportData() {
    return {
        datasetName: document.getElementById('datasetName').value,
        owner: document.getElementById('owner').value,
        responsible: document.getElementById('responsible').value,
        publishDate: document.getElementById('publishDate').value,
        description: document.getElementById('description').value,
        keywords: document.getElementById('keywords').value
    };
}

function generateMetaDocx() {
    const passport = collectPassportData();
    
    // Build structure text for the document
    const structureText = appState.structure.map((s, i) => 
        `${i + 1}. ${s.fieldname} (${s.format}) - ${s.description}`
    ).join('\n');
    
    // Use docxtemplater with loaded template if available
    if (appState.docxTemplate && typeof PizZip !== 'undefined') {
        try {
            const zip = new PizZip(appState.docxTemplate);
            const doc = new docxtemplater(zip, {
                paragraphLoop: true,
                linebreaks: true,
            });
            
            doc.render({
                datasetName: passport.datasetName || 'Не указано',
                owner: passport.owner || 'Не указано',
                responsible: passport.responsible || 'Не указано',
                publishDate: passport.publishDate || 'Не указано',
                description: passport.description || 'Описание отсутствует',
                keywords: passport.keywords || 'Не указаны',
                structureText: structureText
            });
            
            return doc.getZip().generate({
                type: 'blob',
                mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
            });
        } catch (err) {
            console.error('DOCX templater error:', err);
            // Fallback to minimal DOCX generation
        }
    }
    
    // Fallback: create minimal valid DOCX
    return createMinimalValidDocx(passport, structureText);
}

function createMinimalValidDocx(passport, structureText) {
    // Create a minimal valid DOCX file structure
    // DOCX is a ZIP archive containing XML files
    
    const zip = new JSZip();
    
    // [Content_Types].xml
    zip.file('[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>`);
    
    // _rels/.rels
    zip.folder('_rels').file('.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`);
    
    // word/_rels/document.xml.rels
    zip.folder('word').folder('_rels').file('document.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
</Relationships>`);
    
    // Build document content with proper formatting
    const paragraphs = [];
    
    // Title
    paragraphs.push(`<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="32"/></w:rPr><w:t>ПАСПОРТ НАБОРА ОТКРЫТЫХ ДАННЫХ</w:t></w:r></w:p>`);
    paragraphs.push(`<w:p><w:r><w:t></w:t></w:r></w:p>`);
    
    // Section 1
    paragraphs.push(`<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>1. ОБЩАЯ ИНФОРМАЦИЯ</w:t></w:r></w:p>`);
    paragraphs.push(`<w:p><w:r><w:t>Название набора данных: ${escapeXml(passport.datasetName || 'Не указано')}</w:t></w:r></w:p>`);
    paragraphs.push(`<w:p><w:r><w:t>Владелец (ведомство): ${escapeXml(passport.owner || 'Не указано')}</w:t></w:r></w:p>`);
    paragraphs.push(`<w:p><w:r><w:t>Ответственное лицо: ${escapeXml(passport.responsible || 'Не указано')}</w:t></w:r></w:p>`);
    paragraphs.push(`<w:p><w:r><w:t>Дата публикации: ${escapeXml(passport.publishDate || 'Не указано')}</w:t></w:r></w:p>`);
    paragraphs.push(`<w:p><w:r><w:t></w:t></w:r></w:p>`);
    
    // Section 2
    paragraphs.push(`<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>2. ОПИСАНИЕ</w:t></w:r></w:p>`);
    paragraphs.push(`<w:p><w:r><w:t>${escapeXml(passport.description || 'Описание отсутствует')}</w:t></w:r></w:p>`);
    paragraphs.push(`<w:p><w:r><w:t></w:t></w:r></w:p>`);
    
    // Section 3
    paragraphs.push(`<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>3. КЛЮЧЕВЫЕ СЛОВА</w:t></w:r></w:p>`);
    paragraphs.push(`<w:p><w:r><w:t>${escapeXml(passport.keywords || 'Не указаны')}</w:t></w:r></w:p>`);
    paragraphs.push(`<w:p><w:r><w:t></w:t></w:r></w:p>`);
    
    // Section 4
    paragraphs.push(`<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>4. СТРУКТУРА ДАННЫХ</w:t></w:r></w:p>`);
    paragraphs.push(`<w:p><w:r><w:t>Количество полей: ${appState.structure.length}</w:t></w:r></w:p>`);
    paragraphs.push(`<w:p><w:r><w:t>Количество записей: ${appState.rawData.length}</w:t></w:r></w:p>`);
    paragraphs.push(`<w:p><w:r><w:t></w:t></w:r></w:p>`);
    
    // Structure fields
    if (structureText) {
        const lines = structureText.split('\n');
        lines.forEach(line => {
            paragraphs.push(`<w:p><w:r><w:t>${escapeXml(line)}</w:t></w:r></w:p>`);
        });
    }
    paragraphs.push(`<w:p><w:r><w:t></w:t></w:r></w:p>`);
    
    // Section 5
    paragraphs.push(`<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>5. ТЕХНИЧЕСКАЯ ИНФОРМАЦИЯ</w:t></w:r></w:p>`);
    paragraphs.push(`<w:p><w:r><w:t>Дата формирования паспорта: ${escapeXml(new Date().toLocaleString('ru-RU'))}</w:t></w:r></w:p>`);
    paragraphs.push(`<w:p><w:r><w:t>Формат данных: CSV</w:t></w:r></w:p>`);
    paragraphs.push(`<w:p><w:r><w:t>Кодировка: UTF-8</w:t></w:r></w:p>`);
    
    // word/document.xml - the main content
    zip.folder('word').file('document.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
            xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <w:body>
    ${paragraphs.join('')}
  </w:body>
</w:document>`);
    
    // Generate the ZIP file as a blob
    return zip.generateAsync({
        type: 'blob',
        mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    });
}

function escapeXml(text) {
    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;')
        .replace(/\n/g, '</w:t></w:r></w:p><w:p><w:r><w:t>');
}

// Alternative DOCX generation using PizZip and docxtemplater
function generateProperDocx() {
    const passport = collectPassportData();
    
    // This would require loading a template file
    // For the demo, we create a simple structure
    
    const templateText = `ПАСПОРТ НАБОРА ОТКРЫТЫХ ДАННЫХ

1. ОБЩАЯ ИНФОРМАЦИЯ
-------------------
Название набора данных: {datasetName}
Владелец (ведомство): {owner}
Ответственное лицо: {responsible}
Дата публикации: {publishDate}

2. ОПИСАНИЕ
-----------
{description}

3. КЛЮЧЕВЫЕ СЛОВА
-----------------
{keywords}

4. СТРУКТУРА ДАННЫХ
-------------------
Количество полей: ${appState.structure.length}
Количество записей: ${appState.rawData.length}
`;
    
    try {
        const doc = new docxtemplater(templateText, {
            paragraphLoop: true,
            linebreaks: true,
        });
        
        doc.render({
            datasetName: passport.datasetName || 'Не указано',
            owner: passport.owner || 'Не указано',
            responsible: passport.responsible || 'Не указано',
            publishDate: passport.publishDate || 'Не указано',
            description: passport.description || 'Описание отсутствует',
            keywords: passport.keywords || 'Не указаны'
        });
        
        return doc.getZip().generate({
            type: 'blob',
            mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        });
    } catch (err) {
        console.error('DOCX generation error:', err);
        // Fallback to simple blob
        return new Blob([templateText], { 
            type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' 
        });
    }
}
